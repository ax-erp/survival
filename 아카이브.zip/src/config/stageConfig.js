/**
 * Stage and Map terrain configuration
 */

export const WORLD_CONFIG = {
  width: 800,
  height: 1040
};

export const STAGES = [
  {
    stage: 1,
    funnel: {
      left: { x: 330, y: 210, width: 120, height: 15, angle: Math.PI / 6 },
      right: { x: 470, y: 210, width: 120, height: 15, angle: -Math.PI / 6 }
    },
    gate: {
      left: { x: 380, y: 230, width: 40, height: 15 },
      right: { x: 420, y: 230, width: 40, height: 15 }
    },
    pinRows: {
      rows: 5,
      startY: 60,
      rowSpacing: 24,
      evenPins: 14,
      oddPins: 15,
      margin: 40
    }
  },
  {
    stage: 2,
    funnel: {
      left: { x: 340, y: 390, width: 100, height: 15, angle: Math.PI / 6 },
      right: { x: 460, y: 390, width: 100, height: 15, angle: -Math.PI / 6 }
    },
    gate: {
      left: { x: 382.5, y: 410, width: 35, height: 15 },
      right: { x: 417.5, y: 410, width: 35, height: 15 }
    },
    center: { x: 400, y: 313 },
    pins: { count: 4, distance: 60 }
  },
  {
    stage: 3,
    funnel: {
      left: { x: 345, y: 570, width: 90, height: 15, angle: Math.PI / 6 },
      right: { x: 455, y: 570, width: 90, height: 15, angle: -Math.PI / 6 }
    },
    gate: {
      left: { x: 385, y: 590, width: 30, height: 15 },
      right: { x: 415, y: 590, width: 30, height: 15 }
    },
    pinRows: {
      rows: 3,
      startY: 460,
      rowSpacing: 24,
      width: 240,
      centerX: 400,
      evenPins: 7,
      oddPins: 8
    }
  },
  {
    stage: 4,
    funnel: {
      left: { x: 350, y: 750, width: 80, height: 15, angle: Math.PI / 6 },
      right: { x: 450, y: 750, width: 80, height: 15, angle: -Math.PI / 6 }
    },
    gate: {
      left: { x: 387.5, y: 770, width: 25, height: 15 },
      right: { x: 412.5, y: 770, width: 25, height: 15 }
    },
    center: { x: 400, y: 653 },
    pins: { count: 3, distance: 50 }
  },
  {
    stage: 5,
    center: { x: 400, y: 885 }
  }
];

export const DRAIN_ZONES = [
  { x: 100, y: 240, radius: 80, label: 'STAGE 1 DRAIN LEFT' },
  { x: 700, y: 240, radius: 80, label: 'STAGE 1 DRAIN RIGHT' },
  { x: 120, y: 420, radius: 70, label: 'STAGE 2 DRAIN LEFT' },
  { x: 680, y: 420, radius: 70, label: 'STAGE 2 DRAIN RIGHT' }
];
